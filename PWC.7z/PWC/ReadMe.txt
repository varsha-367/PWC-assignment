To Review the assignment-

prerequisite-> should have node installed and configured in env variable of teh system

1) open Node Folder in any Terminal and run npx nodemon index.js , 
this will start the Node server hosted in 8000 port(make sure nothing else is running on the same port)

2) open React Folder in new Terminal to React->users level .

3) run npm install , this will install all dependent package

4) run npm start, you will be able to see UI in your default browser hosted on port 3000(make sure nothing else is running on the same port).

